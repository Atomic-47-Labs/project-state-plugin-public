import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";
import YAML from "yaml";
import { STATE_DIR } from "@/lib/paths";
import type { UseDesignation } from "@/lib/inbox";

const VALID_DESIGNATIONS: UseDesignation[] = [
  "imprint",
  "for-use",
  "example",
  "output",
  "unknown",
];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, designation } = body as { id?: string; designation?: string };

    if (!id || typeof id !== "string") {
      return NextResponse.json({ error: "id is required" }, { status: 400 });
    }
    if (!designation || !VALID_DESIGNATIONS.includes(designation as UseDesignation)) {
      return NextResponse.json(
        { error: `designation must be one of: ${VALID_DESIGNATIONS.join(", ")}` },
        { status: 400 }
      );
    }

    const indexPath = path.join(STATE_DIR, "documents", "index.yaml");

    let raw: string;
    try {
      raw = await fs.readFile(indexPath, "utf8");
    } catch {
      return NextResponse.json({ error: "documents/index.yaml not found" }, { status: 404 });
    }

    const index = YAML.parse(raw) as { entries?: Array<Record<string, any>> };
    if (!index?.entries) {
      return NextResponse.json({ error: "No entries in index" }, { status: 404 });
    }

    const entry = index.entries.find((e) => e.id === id);
    if (!entry) {
      return NextResponse.json({ error: `Document ${id} not found` }, { status: 404 });
    }

    entry.use_designation = designation;
    entry.triage_state = "processed";

    await fs.writeFile(indexPath, YAML.stringify(index), "utf8");

    // Log to activity
    await appendActivityLog({
      event: "inbox.designation.manual_override",
      doc_id: id,
      designation,
      timestamp: new Date().toISOString(),
    });

    return NextResponse.json({ ok: true, id, designation });
  } catch (err) {
    console.error("[inbox/flag]", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

async function appendActivityLog(entry: Record<string, any>) {
  try {
    const logPath = path.join(STATE_DIR, "logs", "activity.ndjson");
    const line = JSON.stringify(entry) + "\n";
    await fs.appendFile(logPath, line, "utf8");
  } catch {
    // Non-fatal — log path may not exist yet
  }
}
